#!/usr/bin/python
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See LICENSE for more details.
#
# Copyright: 2022 IBM
# Author :Vaishnavi Bhat <vaishnavi@linux.vnet.ibm.com?
#        :Praveen K Pandey <praveen@linux.vnet.ibm.com>
#        :Samir A Mulani <samir@linux.vnet.ibm.com> 

from Build_Engine.Distro import *

class UBUNTU(Distro): #Child Class
    def __init__(self):
        pass

    def copy_ubuntu_md5(self,release_name,release_path):
        netboot_url = release_path
        page=urllib2.urlopen(netboot_url)
        soup = BeautifulSoup(page.read(), "html.parser")
        for anchor in soup.findAll('a'):
            link=anchor['href'], anchor.string
            for contents in link:
                if (anchor.string=="ppc64el"):
                    complete_file = parser.read("ubuntu_config.ini")
                    download_path = (parser.items("Download_folder"))
                    server_path=download_path[0][1]
                    self.final_dir_structure=os.path.join(server_path, release_name)
                    netboot_link=anchor['href']

        md5_file = netboot_link.replace("netboot/", "MD5SUMS")
        logging.info("Ubuntu Reading md5sums file from link %s", md5_file)
        local_md5_file = '/tmp/MD5SUMS'
        rc = subprocess.call(["/usr/bin/wget", "-q", md5_file,
                              "--no-check-certificate", "-O", local_md5_file])
        if (rc == 0):
            os.chdir(self.final_dir_structure)
            md5_local = subprocess.check_output(
                ["cat MD5SUMS | grep netboot.tar.gz | awk \'{print $1}\'"], shell=True)
            md5_local = md5_local.strip()
            logging.info("Ubuntu Local md5sum is %s", md5_local)
            md5_gsa = subprocess.check_output(
                ["cat /tmp/MD5SUMS | grep netboot.tar.gz | awk \'{print $1}\'"], shell=True)
            md5_gsa = md5_gsa.strip()
            logging.info("Ubuntu Remote md5sum is %s", md5_gsa)

        if (md5_local == md5_gsa):
            logging.info('Ubuntu MD5SUM matches')
            os.chdir(parser.get('Location', 'base'))
            return FAIL
        else:
            logging.info("Ubuntu MD5SUM doesnt match")
            shutil.copy("/tmp/MD5SUMS", self.final_dir_structure)
            os.chdir(parser.get('Location', 'base'))
            return SUCCESS


    def lts_builds(self,release_name,release_path):
        netboot_url = release_patparserh
        page=urllib2.urlopen(netboot_url)
        soup = BeautifulSoup(page.read(), "html.parser")
        release_name2=release_name+"/"
        for anchor in soup.findAll('a'):
            link=anchor['href'], anchor.string
            for contents in link: 
                if (anchor.string==release_name2):
                    complete_file = parser.read("ubuntu_config.ini")
                    download_path = (parser.items("Download_folder"))
                    server_path=download_path[0][1]
                    final_dir_structure=os.path.join(server_path, release_number, date_dir)
                    netboot_link=release_path+release_name+'/'
                    
                    rc=os.system('wget -q -e robots=off --cut-dirs=100 --reject="index.html*" --no-parent --recursive --relative --level=1 --no-directories -P %s  %s' %(final_dir_structure,netboot_link)) #Downloads files into the specified path
    
                    if (rc == 0):
               
                            self.LOG ('Successfully copied iso_file to '+ final_dir_structure, release_name, release_number)
                            print("Successfully created Log file by name %s, but failed to update into the file" % (release_number))
                            logging.info("Info")
                            logging.debug("Debugf")
                    else:
                            self.LOG ('Failed to copy iso ', release_name, release_number)
                            self.LOG ('MANUAL INTERVENTION REQUIRED' , release_name, release_number)
                            return FAIL
                    break
                else:
                    break

    def non_lts_builds(self,release_name,release_path):
        netboot_url = release_path
        page=urllib2.urlopen(netboot_url)
        soup = BeautifulSoup(page.read(), "html.parser")
        for anchor in soup.findAll('a'):
            link=anchor['href'], anchor.string
            for contents in link: 
                if (anchor.string=="ppc64el"):
                    complete_file = parser.read("ubuntu_config.ini")
                    download_path = (parser.items("Download_folder"))
                    server_path=download_path[0][1]
                    final_dir_structure=os.path.join(server_path, release_name, date_dir)
                    netboot_link=anchor['href']
                    netboot_link += "netboot.tar.gz"
                    logging.info("Ubuntu Downloading files from link %s", netboot_link)
                    rc=os.system('wget -q -e robots=off --cut-dirs=100 --reject="index.html*" --no-parent --recursive --relative --level=1 --no-directories -P %s  %s -O netboot.tar.gz' %(final_dir_structure,netboot_link)) #Downloads files into the specified path
    
                    if (rc == 0):
                        self.LOG ('Successfully copied iso_file to '+ final_dir_structure, release_name, release_name)
                        logging.info("final_dir %s, release_name=%s", final_dir_structure, release_name)
                        # Notify Jenkins
                        self.notify_jenkins('ubuntu', release_name, date_dir, final_dir_structure)
                        # Copy two different files to the newly created folder
                        netboot_file = "/home/jenkins/workspace/build_notifier/ltc-crtl/build_notification/netboot.info"
                        preceed_file = "/home/jenkins/workspace/build_notifier/ltc-crtl/build_notification/preceed.cfg"
                        shutil.copy(netboot_file, final_dir_structure)
                        shutil.copy(preceed_file, final_dir_structure)
                    else:
                        self.LOG ('Failed to copy iso ', release_name, release_name)
                        self.LOG ('MANUAL INTERVENTION REQUIRED' , release_name, release_name)
                        return FAIL
                    break
                else:
                    break
