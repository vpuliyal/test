#!/usr/bin/python2

import build_notification

return_value=build_notification.jenkins_cron_job()

if return_value:
    sys.exit(1)
else:
    sys.exit(0)

