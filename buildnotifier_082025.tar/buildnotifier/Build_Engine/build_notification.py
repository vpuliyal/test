#!/usr/bin/python2
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See LICENSE for more details.
#
# Copyright: 2022 IBM
# Author :Vaishnavi Bhat <vaishnavi@linux.vnet.ibm.com?
#        :Praveen K Pandey <praveen@linux.vnet.ibm.com>
#        :Samir A Mulani <samir@linux.vnet.ibm.com> 

from Build_Engine.suse_obj import *
from Build_Engine.rhel_obj import *
from Build_Engine.ubuntu_obj import *

def build_check_copy(BASE_PATH):
    """
    This function is the start of Build_Engine.
    It will build below platforms,
    1. Redhat
    2. SUSE
    3. Ubuntu
    """
    #rhel_obj(BASE_PATH)
    '''
    set the basedir for suse build
    '''
    os.chdir(BASE_PATH)
    suse_obj(BASE_PATH)
    #ubuntu_obj()


