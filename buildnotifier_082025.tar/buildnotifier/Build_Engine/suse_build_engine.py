#!/usr/bin/python
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See LICENSE for more details.
#
# Copyright: 2022 IBM
# Author :Vaishnavi Bhat <vaishnavi@linux.vnet.ibm.com?
#        :Praveen K Pandey <praveen@linux.vnet.ibm.com>
#        :Samir A Mulani <samir@linux.vnet.ibm.com> 

from Build_Engine.Distro import *

class SUSE(Distro):
    # getting the list of announced builds for SuSE releases from ftp server, since the links to the md5 and
    # iso files are very specific to the build names, the md5link is also
    # formulated here only

    def sdk_populate_builds_copied(self, user, password, release,  release_build_link):
        
        builds_announced.clear()
        md5link_announced.clear()
        temp_file = tempfile.TemporaryFile()
        rc = subprocess.call(["/usr/bin/wget", "-q", "-O", "-", user, password,
                              release_build_link, "--no-check-certificate"], stdout=temp_file)
        temp_file.seek(0)
        with temp_file:
            for lines in temp_file:
                lines = lines.decode()
                lines = lines.strip()
                if not lines.isspace():
                    is_it_release = re.search("Directory", lines)
                    if (is_it_release is not None):
                        is_it_package  = re.search("Packages", lines)
                        is_it_package_sdk  = re.search("SDK", lines)
                        is_it_package_Full  = re.search("Full", lines)
                        is_it_package_SLES  = re.search("SLES", lines)
                        if(is_it_package or is_it_package_sdk or is_it_package_Full or is_it_package_SLES):
                        #if(is_it_package):
                            if not re.search("VMware", lines):
                                build = re.search(
                                    ">(SLE.*-" + release + ".*)</a>.*", lines)
                                    #".*>(SLE.*-" + release + ".*)</a>.*", lines)
                                    #">(SLE.*-" + release + "[^<]*)</a>.*", lines)
                                if build is not None:
                                    print(lines)
                                    print("build",build)
                                    buildname = build.group(1).strip("/")
                                    print("buildname",buildname)
                                    md5link_announced.append(buildname)
                                    check = re.search(
                                        'SLE.*-[0-9]+[0-9]+\.*[0-9]*-', buildname)
                                        #'SLE.[0-9]+[0-9]+-', buildname)
                                    buildname = buildname.replace(
                                        check.group(), '')
                                    bcheck_server = re.search('SDK-', buildname)
                                    bcheck = re.search('Installer-', buildname)
                                    bcheck_full= re.search('Full-', buildname)
                                    if bcheck:
                                        buildname = buildname.replace(
                                            bcheck.group(), '')
                                    if bcheck_server:
                                        buildname = buildname.replace(bcheck_server.group(), '')
                                    if bcheck_full:
                                        buildname = buildname.replace(bcheck_full.group(), '')
                                    builds_announced.append(buildname.lower())
        builds_announced.sort()
        md5link_announced.sort()
        logging.info('SuSE: Builds announced %s', str(builds_announced))
        return SUCCESS

    def populate_builds_announced(self, user, password, release,  release_build_link):
        
        builds_announced.clear()
        md5link_announced.clear()
        temp_file = tempfile.TemporaryFile()
        rc = subprocess.call(["/usr/bin/wget", "-q", "-O", "-", user, password,
                              release_build_link, "--no-check-certificate"], stdout=temp_file)

        temp_file.seek(0)
        with temp_file:
            for lines in temp_file:
                lines = lines.decode()
                lines = lines.strip()
                if not lines.isspace():
                    is_it_release = re.search("Directory", lines)
                    if (is_it_release is not None):
                        is_it_server = re.search("Server", lines)
                        is_it_sles = re.search("Installer", lines)
                        is_it_sles_full = re.search("Full", lines)
                        is_it_package_SLES  = re.search("SLES", lines)
                        if(is_it_sles or is_it_server or is_it_sles_full or is_it_package_SLES):
                            if not re.search("VMware", lines):
                                build = re.search(
                                    ">(SLE.*-" + release + ".*)</a>.*", lines)
                                    #".*>(SLES.*-" + release + ".*)</a>.*", lines)
                                if build is not None:
                                    buildname = build.group(1).strip("/")
                                    md5link_announced.append(buildname)
                                    check = re.search(
                                        'SLE.*-[0-9]+[0-9]+\.*[0-9]*-', buildname)
                                        #'SLES.[0-9]+[0-9]+-', buildname)
                                    buildname = buildname.replace(
                                        check.group(), '')
                                    bcheck_ser = re.search('Server-', buildname)
                                    bcheck = re.search('Installer-', buildname)
                                    bcheck_full = re.search('Full-', buildname)
                                    if bcheck:
                                        buildname = buildname.replace(
                                            bcheck.group(), '')
                                    if bcheck_ser:
                                        buildname = buildname.replace(bcheck_ser.group(), '')
                                    if bcheck_full:
                                        buildname = buildname.replace(bcheck_full.group(), '')
                                    builds_announced.append(buildname.lower())

        builds_announced.sort()
        md5link_announced.sort()
        logging.info('SuSE: Builds %s', str(builds_announced))
        print('SuSE: Builds announced %s', str(builds_announced))
        return SUCCESS

    # populating the list of already copied builds
    def populate_builds_copied(self, release, release_build_copied):
        if release_build_copied is not None:
            builds_copied.clear()
            with open(release_build_copied, 'r') as file:
                for builds in file:
                    builds = builds.rstrip()
                    builds_copied.append(builds.lower())
            builds_copied.sort()
            logging.info('Builds copied %s', str(builds_copied))
            return SUCCESS

    # copying the  build: first the md5 and then iso
    def copy_suse_build(self, user, password, build_name, final_dir_structure):
        print("inside copy_suse_build")
        rc = self.copy_suse_md5(user, password, release,
                                build_name,  final_dir_structure)
        print('in copy_suse_build')
        print(rc)
        if (rc != 0):
            self.LOG(
                'May be the complete directory contents of build are not available yet. Will try in another hour', release, build_name)
            return MD5_NA
        else:
            rc = self.copy_suse_iso(
                user, password, release, build_name, final_dir_structure)
            if (rc != 0):
                return FAIL

    # copying the md5 sum file from ftp server
    def copy_suse_md5(self, user, password, release, build_name, final_dir_structure):
        md5local = final_dir_structure + '/MD5SUM'
        md5links = []
        md5link_flag = False
        announced_build = md5link_announced[builds_announced.index(build_name)]
        for iso in range(1,3):
            data = announced_build.split("-")
            data.insert(4, "ppc64le")
            #string = "Media" + str(iso) + ".iso.sha256"
            #SP6, SP7 distro
            string = "*" + "Media" + str(iso) + ".iso.sha256"
            #string = "*" + "Beta" + str(iso) + ".iso.sha256"
            #SLES16 Distro 
            #string = "*"  + ".iso"
            data.insert(len(data), string)
            iso_link = '-'.join(data)
            print(iso_link)
            md5link = parser.get('Location', 'base_link') + announced_build + "/" +iso_link
            md5links.append(md5link)
        
        for links in md5links:
            temp_file = tempfile.TemporaryFile()
            rc = subprocess.call(["/usr/bin/wget", "-q", "-O", "-", user,
                                  password, links, "--no-check-certificate"], stdout=temp_file)
            print('Inside md5links')
            print("/usr/bin/wget", "-q", "-O", "-", user,password, links, "--no-check-certificate")
            print(rc)
            if (rc == 0):
                temp_file.seek(0)
                iso_build = []
                with open(md5local, 'a+') as file:
                    with temp_file:
                        for lines in temp_file:
                            lines = lines.decode()
                            lines = lines.strip()
                            if (lines.isspace()):
                                pass
                            else:
                                is_it_ppc = re.search("ppc64", lines)
                                if (is_it_ppc is not None):
                                    is_it_firstcd = re.search("[1-2].iso", lines)
                                    if(is_it_firstcd is not None):
                                        file.write(lines + "\n")

                self.LOG('Successfully copied MD5SUM ' +
                         os.getcwd(),  release,  build_name)
                md5link_flag = True
            else:
                self.LOG('Failed to copy MD5SUM', release, build_name)
                return FAIL

        if md5link_flag:
                return SUCCESS


    # Copy the iso file. Pick the iso file name from MD5 file copied earlier
    def copy_suse_iso(self, user, password, release,  build_name, final_dir_structure):
        md5_file = final_dir_structure + '/MD5SUM'
        local_iso_file = ""
        global src_build_flag
        src_build_flag = True
        with open(md5_file, 'r') as file, open(md5_file, 'r') as file_obj:
            '''
            MD5_FILE build check_point
            '''
            build_data = file_obj.readlines()
            lenght = len(build_data)
            if(lenght == 1):
                match_iso = re.search("2.iso", build_data[0])
                if(match_iso):
                    src_build_flag = False
                    
            for lines in file:
                lines = lines.strip()
                if(lines.isspace()):
                    pass
                else:
                    is_it_iso = re.search("iso", lines)
                    if (is_it_iso is not None):
                        iso_file = lines.split(" ")[2]
                        full_iso_file = parser.get('Location', 'base_link') + md5link_announced[
                            builds_announced.index(build_name)] + '/' + iso_file
                        sec_iso_dir = re.search("2.iso", lines)
                        if(sec_iso_dir and src_build_flag):
                            build_dir_name = "src"
                            sec_iso_final_path = os.path.join(final_dir_structure, build_dir_name)
                            if os.path.isdir(sec_iso_final_path):
                                pass
                            else:
                                os.makedirs(sec_iso_final_path)
                            local_iso_file = sec_iso_final_path + '/' + iso_file
                        else:
                            local_iso_file = final_dir_structure + '/' + iso_file
                        print("Copying SUSE iso: ", full_iso_file)
                        print("local_iso_file path: ", local_iso_file)
                        rc = subprocess.call(["/usr/bin/wget", user, password, "-q",
                                              full_iso_file, user, "--no-check-certificate", "-O", local_iso_file])
                        if (rc == 0):
                            self.LOG('Successfully copied iso_file to ' +
                                     os.getcwd(), release, build_name)
                        else:
                            self.LOG('Failed to copy iso ',
                                     release, build_name)
                            self.LOG('MANUAL INTERVENTION REQUIRED',
                                     release, build_name)
                            return FAIL
        return SUCCESS
    
    def copytree(self, src, dst, symlinks=False, ignore=None):
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                shutil.copytree(s, d, symlinks, ignore)
            else:
                shutil.copy2(s, d)

    def copy_sdk_build(self, release):
        for build in new_builds[:]:
            if 'packages' in build  or  'sdk' in build:
                build_sdk = build.split('-')
                inter_build = build_sdk[0]
                inter_build_1 =  build_sdk[2]
                final_dir_structure = parser.get('Location', 'dir_structure')+'/'+release+inter_build+'/'+inter_build_1
                package_dir = parser.get('Location', 'dir_structure')+'/'+release+inter_build+'/'+build_sdk[1]
                try:
                    os.makedirs(final_dir_structure+'/sdk')
                except OSError as e:
                    pass
                try:
                    self.copytree(package_dir,  final_dir_structure+'/sdk')
                except OSError as e:
                    pass
                try:
                    shutil.rmtree(package_dir)
                except OSError as e:
                        pass
                
    def initiate_suse_build_copy(self, user, password, release, config_path):
        # Create the directory structure
        Build_dir=[]
        for build in new_builds[:]:
            final_dir_structure = parser.get(
                #'Location', 'dir_structure') + release + '/' + build
                'Location', 'dir_structure') + '/' + release + '/' + build
            self.LOG('Starting copying of ' + build +
                     ' for ' + release, release, build)
            print(build)
            build_attribute=build.split('-')
            release_ver = release.split("-")
            release_sles15 = release_ver[0]+build_attribute[0]
            #Checkpoint to avoid the duplicate build folder
            print(build_attribute)
            if(len(build_attribute) == 4):
                final_dir_structure = parser.get('Location', 'dir_structure')+ '/'+release_ver[0]+build_attribute[0]+'/'+build_attribute[1] + "-" + build_attribute[2] + "-" + build_attribute[3]
            elif(len(build_attribute) == 1):
                final_dir_structure = parser.get('Location', 'dir_structure')+ '/'+release_ver[0]+build_attribute[0]
            else:
                final_dir_structure = parser.get('Location', 'dir_structure')+ '/'+release_ver[0]+build_attribute[0]+'/'+build_attribute[1]
            rc = self.create_dir_structure(release, build, final_dir_structure)
            if (rc != 0):
                self.LOG('Failed to copy build', release, build)
                return FAIL

            # downloading the md5sum and iso file from ftp
            Build_dir.append(final_dir_structure)
            rc = self.copy_suse_build(
                user, password, build, final_dir_structure)
            if (rc != 0):
                if (rc == 2):
                    self.restore_for_copy_again(
                        release, build, final_dir_structure)
                    continue
            rc = self.check_md5sum(release, build, final_dir_structure)
            if (rc != 0):
                self.LOG('MD5 check failed. Will try copy again', release, build)
                self.restore_for_copy_again(
                    release, build, final_dir_structure)
                md5_cpy = final_dir_structure + '/MD5SUM_BACKUP'
                md5file = final_dir_structure + '/MD5SUM'
                os.rename(md5file, md5_cpy)

                return FAIL
            else:
                build_attribute=build.split('-')
                if(len(build_attribute) == 1):
                    build_sles15=build_attribute[0]
                else:
                    build_sles15=build_attribute[1]
                src_dir_check = final_dir_structure + '/'+ "src"
                if os.path.isdir(src_dir_check):
                    Build_dir.append(src_dir_check)
                Build_dir.append(config_path)
                self.publish_build(release_sles15, build_sles15, parser.get('Location', 'dir_structure'), Build_dir)
                self.Version(build)
                self.update_builds_copied(release, build)
                if 'packages' in build or 'sdk' in build:
                    print("no need to notify")
                else:
                    build_attribute=build.split('-')
                    if(len(build_attribute) == 1):
                        build_sles15=build_attribute[0]
                    else:
                        build_sles15=build_attribute[1]
                    #build_sles15=build_attribute[1]
                    self.notify_jenkins('sles', release_sles15, build_sles15, final_dir_structure)
            md5_cpy = final_dir_structure + '/MD5SUM_BACKUP'
            md5file = final_dir_structure + '/MD5SUM'
            os.rename(md5file, md5_cpy)
            '''
            if 'packages' in build:
                print "no need to notify"
            else:
                self.notify_build_copy(
                    self.__class__.__name__, release, build, final_dir_structure)
            '''
