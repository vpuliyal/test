#!/usr/bin/python2

import paramiko
import  pexpect
import os
import commands
import sys
import socket

#global parameter
ssh = paramiko.SSHClient()


try:
    #host = '9.40.200.43'
    #host = '9.40.201.84'
    host = '10.48.26.172'
    user = 'root'
    password = 'passw0rd'

except IndexError:

    print(" Pass IP Address , user , password")
    print(" Usages ex:  python rastest_fvtpy 911111112 root pass4root")
    #exit(-1)

ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(host, username=user, password=password)
print("host-",host)
print("password-",password)
buildfile = open("/home/jenkins/workspace/buildnotifier/buildfile", "r")

for lines in buildfile:
    value=lines.split('\n')
    distro=value[0]
    cmd='/home/jenkins/userContent/distro-ci/cibuildnotifier_parser.py %s' %distro
    stdin, stdout, stderr = ssh.exec_command(cmd, timeout=10)
    print(cmd)
    try:
            for l in stdout:
                    print("%s" % l.encode('utf-8').strip())
    except socket.error:
            print("failed")

    try:
            for l in stderr:
                    print("%s" % l.encode('utf-8').strip())
    except socket.error:
            print("failed")

