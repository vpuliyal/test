#!/usr/bin/python
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See LICENSE for more details.
#
# Copyright: 2022 IBM
# Author :Vaishnavi Bhat <vaishnavi@linux.vnet.ibm.com?
#        :Praveen K Pandey <praveen@linux.vnet.ibm.com>
#        :Samir A Mulani <samir@linux.vnet.ibm.com>

import os
import re
import logging
from logging import Formatter
import configparser
import tempfile
import pdb
from bs4 import BeautifulSoup
import urllib.request as urllib2
import webbrowser
import time
from datetime import date
import calendar
import subprocess
import datetime
import sys
import shutil
import numpy as np 
from Build_Engine.publishBuild import *
parser = configparser.SafeConfigParser()

builds_announced = []
builds_copied = []
new_builds = []
ftp3_user=''
ftp3_password =''
md5link_announced= []
release=''
SUCCESS = 0
FAIL = 1
release_list = []
MD5_NA = 2
publish_conf_dir = os.getcwd()
dirfmt = "%4d%02d%02d"
date_dir = dirfmt % time.localtime()[0:3]
ci_notify =[]

def get_value():
        return ci_notify

class Distro (object):

    def LOG(self, message, release, build):
        build_specific_loglocation = parser.get('Location', 'build_log')
        if not os.path.exists(build_specific_loglocation):
            os.makedirs(build_specific_loglocation)
        build_specific_log = parser.get(
            'Location', 'build_log') + release + '_' + build + '.log'
        logger = logging.getLogger(__name__)
        handler = logging.FileHandler(build_specific_log)
        handler.setLevel(logging.INFO)
        FORMAT = '%(asctime)-10s %(message)s'
        DATE_FORMAT = '%b %d %H:%M:%S'
        formatter = Formatter(fmt=FORMAT, datefmt=DATE_FORMAT)
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        message = 'For release ' + release + ' and build ' + build + ' - ' + \
            message
        logger.info(message)
        logger.removeHandler(handler)

    def __init__(self, configFile):
        ci_notify.clear()
        self.configFile = configFile
        parser.read(self.configFile)
        main_log_filename = parser.get('Log', 'main_log')
        if not os.path.exists(os.path.dirname(main_log_filename)):
            os.makedirs(os.path.dirname(main_log_filename))
        logging.basicConfig(filename=main_log_filename,
                            format='%(asctime)-10s %(message)s',
                            datefmt='%b %d %H:%M:%S', level=logging.INFO)

    def reading_configFile(self):
        release_list_from_configfile = parser.get(
            'Location', 'releases').split(',')
        return release_list_from_configfile

    def get_build_link(self, release):
        release_build_link = parser.get('Location', 'base_link') + release
        return release_build_link

    def build_copied(self, release):
        """ Read the build_copied file and populate builds_copied list"""
        if release:
            release_build_copied = parser.get(
                'Location', 'build_copied') + '_' + release
            if not os.path.exists(release_build_copied):
                f = open(release_build_copied, 'w+')
            return release_build_copied

    def compare_for_newbuild(self):
        """Compare the two list and return the new build found
        in builds_announced list
        """
        print("builds_announced = ",builds_announced)
        print("builds_copied = ",builds_copied)
        print(parser.get('Location', 'build_copied'))
        if builds_announced == builds_copied:
            print("No new builds")
            logging.info('No new builds')
        else:
            new_builds1 = list(set(builds_announced) - set(builds_copied))
            new_builds.clear()
            for build in new_builds1:
                new_builds.append(build)
            new_builds.sort()
            logging.info('New builds %s', str(new_builds))
            print('New builds %s', str(new_builds))
            return new_builds

    """Specific build portions start from here"""

    def create_dir_structure(self, release, build, final_dir_structure):
        """Create the directory structure required"""

        self.LOG('Creating dir structure ' +
                 final_dir_structure, release, build)
        try:
            if not os.path.exists(final_dir_structure):
                os.makedirs(final_dir_structure)
           
                self.LOG('Successfully created ' +
                         final_dir_structure, release, build)
                print("final_dir_structure=%s, release=%s, build=%s" %(final_dir_structure, release, build))
                return SUCCESS
            else:
                return SUCCESS
        except OSError:
            self.LOG('Failed to create ' + final_dir_structure +
                     ' Failing copy ' + release + ' ' +build, release, build)
            return FAIL

    def copy_md5(self, user, password, release, build_name, final_dir_structure):
        """Copy the md5 file locally"""
        md5_file = parser.get('Location', 'base_link') + \
            release + '.' + build_name + '/isos/binary/MD5SUM'
        local_md5_file = final_dir_structure + '/MD5SUM'
        print("/usr/bin/wget", "-q", user, password, md5_file,"--no-check-certificate", "-O", local_md5_file)
        rc = subprocess.call(["/usr/bin/wget", "-q", user, password, md5_file,
                              "--no-check-certificate", "-O", local_md5_file])
        print(rc)
        if (rc == 0):
            self.LOG('Successfully copied MD5SUM ' +
                     os.getcwd(), release, build_name)
            return SUCCESS
        else:
            self.LOG('Failed to copy MD5SUM', release, build_name)
            return FAIL

    def copy_iso(self, user, password, release, build_name, final_dir_structure):
        """Copy the iso file. Pick the iso file name from
        MD5 file copied earlier
        """
        md5_file = final_dir_structure + '/MD5SUM'
        with open(md5_file, 'r') as file:
            for lines in file:
                lines = lines.strip()
                if(lines.isspace()):
                    pass
                else:
                    is_it_iso = re.search("iso", lines)
                    if (is_it_iso is not None):
                        iso_file = lines.split(" ")[2]
                        full_iso_file = parser.get(
                            'Location', 'base_link') + release + '.' + \
                            build_name + '/isos/binary/' + iso_file
                        local_iso_file = final_dir_structure + '/' + iso_file
                        rc = subprocess.call(
                            ["/usr/bin/wget", "-q", user, password, full_iso_file,
                             "--no-check-certificate", "-O", local_iso_file])
                        if (rc == 0):
                            self.LOG('Successfully copied iso_file to ' +
                                     os.getcwd(), release, build_name)
                            return SUCCESS
                        else:
                            self.LOG('Failed to copy iso ',
                                     release, build_name)
                            self.LOG('MANUAL INTERVENTION REQUIRED',
                                     release, build_name)
                            return FAIL

    def copy_build(self, user, password, build_name, final_dir_structure):
        """Wrapper function for build copying"""
        rc = self.copy_md5(user, password, release, build_name, final_dir_structure)
        if (rc != 0):
            self.LOG(
                'May be the complete directory contents of build are not \
                 available yet. Will try in another hour', release, build_name)
            return MD5_NA
        else:
            rc = self.copy_iso(user, password, release, build_name, final_dir_structure)
            if (rc != 0):
                return FAIL

    def check_md5sum(self, release, build, final_dir_structure):
        try:
            os.chdir(final_dir_structure)
        except OSError:
            self.LOG('Failed to cd to ' + final_dir_structure +
                     ' Need manual intervention', release, build)
            return FAIL
        try:
            md5_local = subprocess.check_output(
                ["md5sum *.iso | awk \'{print $1}\'"], shell=True)
            md5_local = md5_local.strip()
        except subprocess.CalledProcessError:
            self.LOG('Failed to get md5sum of iso file', release, build)
            os.chdir(parser.get('Location', 'base'))
            return FAIL
        try:
            md5_gsa = subprocess.check_output(
                ["cat MD5SUM | grep *.iso | awk \'{print $1}\'"], shell=True)
            md5_gsa = md5_gsa.strip()
        except subprocess.CalledProcessError:
            self.LOG('Failed to get md5sum from MD5SUM file', release, build)
            os.chdir(parser.get('Location', 'base'))
            return FAIL

        if (md5_local == md5_gsa):
            self.LOG('MD5SUM matches', release, build)
            os.chdir(parser.get('Location', 'base'))
            return SUCCESS
        else:
            self.LOG('MD5SUM doesnt match', release, build)
            os.chdir(parser.get('Location', 'base'))
            #return FAIL
            return SUCCESS

    def restore_for_copy_again(self, release, build, final_dir_structure):
        self.LOG('Removing all the files and dir ' +
                 final_dir_structure + ' for incomplete copy', release, build)
        files = []
        files = os.listdir(final_dir_structure)
        for file in files:
            file = final_dir_structure + '/' + file
            #os.rmdir(file)
            os.remove(file)
            #shutil.rmtree(file)
        try:
            os.rmdir(final_dir_structure)
        except OSError:
            self.LOG('Couldnt remove the directory structure ' +
                     final_dir_structure, release, build)
            self.LOG('NEED MANUAL INTERVENTION', release, build)
            return FAIL

    def publish_build(self, release, build_name, dir_structure, config_dir):
        """Create the directories required to create petitboot.conf"""
        build_log = parser.get('Location', 'build_log') + \
            '/' + release + '_' + build_name + '.log'
        rc = publish(
            release, build_name, dir_structure, build_log, config_dir)
        if (rc == SUCCESS):
            self.LOG(build_name + ' has been published ', release, build_name)
        else:
            self.LOG('Publish of ' + build_name +
                     ' has failed.', release, build_name)

    def update_builds_copied(self, release, build):
        print(parser.get('Location', 'build_copied') + '_' + release)
        with open(parser.get('Location', 'build_copied') +
                  '_' + release, 'a') as file:
            file.write(build + "\n")
            return SUCCESS

    def notify_jenkins(self, host_os, release, build, final_dir_structure):
        print("in notify_jenkins")
        build_notify_file = parser.get('Location', 'crtl_poll_file')
        vm_notify_file = parser.get('Location', 'vm_poll_file')
        nv_notify_file = parser.get('Location', 'nv_poll_file')

        for notify_file in build_notify_file, vm_notify_file, nv_notify_file:
            if not os.path.exists(os.path.dirname(notify_file)):
                os.makedirs(os.path.dirname(notify_file))
            try:
                file = open(notify_file, 'w+')
            except OSError:
                self.LOG('Couldnt notify jenkins poll dir' +
                         notify_file, release, build)

            file.write(host_os + '_' + release + '_' + build + '\n')
            file.close()
        ci_notify_file=''
        ci_notify_location = parser.get('Location', 'ci_poll_location')
        if not os.path.exists(ci_notify_location):
            os.makedirs(ci_notify_location)
        ci_notify_file = ci_notify_location + '/' + \
            host_os + '_' + release + '_'+build
        ci_notify_str = host_os + '_' + release  + '_'+build
        ci_notify.append(ci_notify_str)
        print(final_dir_structure)
        os.chdir(final_dir_structure)
        try:
            file = open(ci_notify_file, 'w+')
        except OSError:
            self.LOG('Couldnt notify jenkins poll dir' +
                     ci_notify_file, release, build)

        if (('opal' not in host_os) and ('OpenPower' not in host_os)):
            pwd = os.getcwd()
            print("Present Working Directory:", pwd)
            iso_filename = subprocess.check_output(["ls *.iso"], shell=True)
            iso_filename = iso_filename.strip(b'\n')
        else:
            iso_filename = ' '
        iso_filename = iso_filename.decode()
        file.write(iso_filename + '\n')
        file.close()
        os.chdir(parser.get('Location', 'base'))
        return SUCCESS

    def notify_build_copy(self, name, release, build, final_dir_structure, config_path):
        """Notify the list of people provided in config file"""
        #import smtplib

        id_list = parser.get('Email', 'notify_ids').split(',')
        fromaddr = parser.get('Email', 'fromaddr')
        message_subject = "Build %s:%s:%s has been announced" % (
            name, release, build)

        """Section to build the text for the mail"""
        build_log = parser.get('Location', 'build_log') + \
            release + '_' + build + '.log'
        message_text = "Hi,\n"
        build_log = config_path + "/" + build_log
        with open(build_log, 'r') as file:
            for line in file:
                if line not in message_text:
                    message_text = message_text + line

        message = "From: %s\r\n" % fromaddr\
            + "To: %s\r\n" % id_list[0]\
            + "CC: %s\r\n" % ",".join(id_list[1:])\
            + "Subject: %s\r\n" % message_subject\
            + "\r\n"\
            + message_text
        #mail = smtplib.SMTP('ap.relay.ibm.com')
        #mail.sendmail(fromaddr, id_list, message)

    def initiate_build_copy(self, user, password, release):
        """Create the directory structure"""
        for build in new_builds:
            final_dir_structure = parser.get(
                'Location', 'dir_structure') + release + '/' + build
            self.LOG('Starting copying of ' + build +
                     ' for ' + release, release, build)
            rc = self.create_dir_structure(release, build, final_dir_structure)
            if (rc != 0):
                self.LOG('Failed to copy build', release, build)
                return FAIL
            rc = self.copy_build(user, password, build, final_dir_structure)
            if (rc != 0):
                if (rc == 2):
                    self.restore_for_copy_again(
                        release, build, final_dir_structure)
                    return FAIL

            rc = self.check_md5sum(release, build, final_dir_structure)
            rc = 0
            if (rc != 0):
                self.LOG('MD5 check failed. Will try copy again',
                         release, build)
                self.restore_for_copy_again(
                    release, build, final_dir_structure)
                return FAIL
            else:
                self.publish_build(release, build, parser.get(
                    'Location', 'dir_structure'))
                self.Version(build)
                self.update_builds_copied(release, build)
                self.notify_jenkins('pkvm', release, build,
                                    final_dir_structure)

            self.notify_build_copy(
                self.__class__.__name__, release, build, final_dir_structure)

    def Latest(self, release):
        release_dir = parser.get('Location', 'dir_structure') + release
        os.chdir(release_dir)
        ls_list = []
        build_list = subprocess.check_output(["ls -t"], shell=True)
        ls_list = build_list.splitlines()
        if ls_list:
            if os.path.islink("latest"):
                os.unlink("latest")
                latest_build = ls_list[0]
            else:
                latest_build = ls_list[0]
            os.symlink(latest_build, "latest")

    def Version(self, build):
        with open("version", "w") as file:
            file.write(build)

