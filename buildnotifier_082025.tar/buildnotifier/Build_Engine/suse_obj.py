#import sys
#sys.path.append("..")
#from Distro.Dis_cls_engine import *
#from suse.suse_build_engine import *
from Build_Engine.suse_build_engine import *
#from Build_Engine.Distro import *

def suse_obj(platform_config_path):
    build_file='buildfile'
    file = open(build_file, 'a+')
    suse_build = SUSE(platform_config_path + "/config/suse_config.ini")
    release_list = suse_build.reading_configFile()
    # the username and password required for ftp login is read from the config
    # file and passed on to the functions
    ftp3_user = '--user=' + parser.get('Email', 'user')
    ftp3_password = '--password=' + parser.get('Email', 'passwd')
    release_build_link = parser.get('Location', 'base_link')
    print("release_list =",release_list)
    for release in release_list:
        builds_announced = []
        md5link_announced = []
        builds_copied = []
        new_builds = []
        suse_build.populate_builds_announced(
            ftp3_user, ftp3_password, release, release_build_link)
        Release_build_copied = suse_build.build_copied(release)
        suse_build.populate_builds_copied(release, Release_build_copied)
        new_builds = suse_build.compare_for_newbuild()
        if new_builds:
            suse_build.initiate_suse_build_copy(ftp3_user, ftp3_password, release, platform_config_path)
            #suse_build.Latest(release)
            if 'packages' in new_builds  or  'sdk' in new_builds:
                print("no new build ")
            else:
                ci_notify_data = get_value()
                for build_name in ci_notify_data:
                    file.write(build_name)
                    file.write("\n")
    for release in release_list:
        builds_announced = []
        md5link_announced = []
        builds_copied = []
        new_builds = []
        suse_build.sdk_populate_builds_copied(ftp3_user, ftp3_password, release, release_build_link)
        Release_build_copied = suse_build.build_copied(release)
        suse_build.populate_builds_copied(release, Release_build_copied)
        new_builds = suse_build.compare_for_newbuild()
        if new_builds:
            suse_build.initiate_suse_build_copy(ftp3_user, ftp3_password, release, platform_config_path)
            suse_build.copy_sdk_build(release)
    file.close()

