from Build_Engine.redhat_build_engine import *
from Build_Engine.Distro import *


def rhel_obj(platform_config_path):
    build_file='buildfile'
    file = open(build_file, 'a+')
    rhel_build = RHEL(platform_config_path+"/config/rhel_config.ini")
    release_list = rhel_build.reading_configFile()
    ftp3_user = '--user=' + parser.get('Email', 'user')
    ftp3_password = '--password=' + parser.get('Email', 'passwd')
    release_build_link = parser.get('Location', 'base_link')
    for release in release_list:
        builds_announced = []
        builds_copied = []
        new_builds = []
        optional = ''
        if release > '7':
            if re.search("LE", release) is not None:
                temp = release.lower().split('-')
                release_new = temp[1] + temp[0]
                optional= str(temp[1])
            else:
                release_new = release.lower() + 'be'
        else:
            optional_release = release
            release_new = release.lower()

        rhel_build.populate_builds_announced(
            ftp3_user, ftp3_password, release, release_build_link)
        Release_build_copied = rhel_build.build_copied(release_new)
        rhel_build.populate_builds_copied(release.lower(), Release_build_copied)
        new_builds = rhel_build.compare_for_newbuild()
        if new_builds:
            rhel_build.initiate_rhel_build_copy(
            ftp3_user, ftp3_password, release, release_new, platform_config_path)
            rhel_build.Latest(release_new)
            ci_notify_data = get_value()
            for build_name in ci_notify_data:
                file.write(build_name)
                file.write("\n")
    file.close()
