#! /usr/local/bin/python

#Publish the build passed to. 
#Inputs needed 
#1) Build location /var/www/html/kopbuild211
#2) Name of the build 0.12.0               
#Unwrap the iso and copy the files
#Create the petitboot without default label
#Modify /etc/dhcpd.confd

import os, re, subprocess, time, pdb
variables_publish={}
SUCCESS=0
FAIL=1
BUILD_LOCATION_DOESNT_EXIST = 2
ISO_NOT_FOUND = 3
MOUNT_FAILURE = 4
COPY_FILE_FAILURE = 5
ISO_DIR_CREATION_FAILURE=''

def create_Petitboot (release, build_name, location, new_petitboot_file, default_flag):
    """
      Read the petitboot_template and change Tags with real values
    """
    # Create the new petitboot file
    path = variables_publish['build_path'] + release + '/'
    with open (new_petitboot_file, 'a') as new_file :
        with open (variables_publish['template_file'], 'r') as temp_file :
            for line in temp_file :
                new_line = re.sub('RELEASE', release, line)
                new_line = re.sub('BUILDID', build_name, new_line)
                new_line = re.sub('REPO_SERVER', variables_publish['repo_server'], new_line)
                new_line = re.sub('PATH', path, new_line)
                if (re.search("label", new_line) != None):
                    new_file.write(new_line)
                else :
                    new_line = " " + new_line
                    new_file.write(new_line)

def unWrap_iso (build_and_location):
    """
      Retrieve the files out of iso
    """
    print("In Side unWrap_iso")
    print(build_and_location)
    iso_count = 1
    for build_path in build_and_location:
        iso = '/iso'+ str(iso_count)
        try:
            iso_build_dirext = build_path + iso 
            if os.path.isdir(iso_build_dirext):
                pass
            else:
                os.makedirs(iso_build_dirext)
        except OSError as e:
            print(e.errno)
            print(e.filename)
            print(e.filename)
            return ISO_DIR_CREATION_FAILURE
        os.chdir(build_path)
        mount_command = "mount -o loop *.iso" + " " + ".%s"%(iso)
        print(mount_command)
        print('Publish 1')
        umount_command = "umount .%s"%(iso)
        if os.path.ismount(mount_command):
            pass
        else:
            subprocess.call([umount_command], shell = True)
            rc = subprocess.call([mount_command], shell = True)
            if (rc != 0):
                return MOUNT_FAILURE
    
        copy_command = "cp -a .%s/*"%(iso) + " " + build_path
        rc = subprocess.call([copy_command], shell = True) 
        if (rc != 0):
            subprocess.call([umount_command], shell = True)
            return COPY_FILE_FAILURE
    
        subprocess.call([umount_command], shell = True)
        if(len(build_and_location) == iso_count):
            return SUCCESS
        iso_count = iso_count + 1

    
def check_dir_iso (build_and_location):
   """
     Check for the location and build to be  present
   """
 
   #if ( os.path.isdir(build_and_location) is not True ):
   #   return BUILD_LOCATION_DOESNT_EXIST
   #else :
       #Check for iso file to be present
   command = "/bin/ls -l" + " " + build_and_location + "| grep iso | grep -qv \"^d\""
   rc = subprocess.call([command], shell=True)
   if ( rc != 0 ):
       return ISO_NOT_FOUND

def Log (log_file, string) :
   """
      Open the log_file in write mode and insert string
   """
   log_file = config_file_path + "/" + log_file
   with open(log_file, 'a') as file :
      localtime = time.asctime(time.localtime(time.time()))
      final_log = localtime+" "+string+'\n'
      file.write(final_log)
   return 0

def publish (release, build_name, location, build_log, config_file) :
   build_dir = []
   global config_file_path 
   if (type(config_file) == list) :
       config_file_path = config_file.pop()
       build_dir = config_file
   else:
        config_file_path = config_file
        build_loc = location + '/' + release + '/' + build_name
        build_dir.append(build_loc)
   config_path = config_file_path + '/config/publish_config'
   with open(config_path, 'r') as file :
       for line in file:
           var, value = line.split('=')
           variables_publish[var] = value.strip()

   rc = unWrap_iso (build_dir)
   if ( rc == MOUNT_FAILURE ):
      Log (build_log, 'Mount of iso failed. Failing publish')
      return FAIL
   elif (rc == COPY_FILE_FAILURE):
      Log (build_log, 'Couldnt copy contents of iso to %s' % location)
      return FAIL
   else :
       Log (build_log, 'Successfully unwrapped iso')

   """
      Create the arguments for petitboot
   """
   new_petitboot_file = build_dir[0] + "/" + 'petitboot.conf'
   default_flag = 'No'
   rc = create_Petitboot (release, build_name, location, new_petitboot_file, default_flag)
   if ( rc == FAIL ):
       Log (build_log, 'Petitboot for build' + build_name + 'creation failed.')
       Log (build_log, 'Manual intervention required')
       return FAIL
   else :
       Log (build_log, 'Petitboot for build' + build_name + 'created successfully')
       return SUCCESS

   #modify_dhcp()
   #Read dhcp configs from dhcp_config file
 
   #restart_dhcpd ()

   #notify_team() 
