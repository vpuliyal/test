#!/usr/bin/python
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See LICENSE for more details.
#
# Copyright: 2018 IBM
# Author :Vaishnavi Bhat <vaishnavi@linux.vnet.ibm.com?
#        :Praveen K Pandey <praveen@linux.vnet.ibm.com>
#        :Samir A Mulani <samir@linux.vnet.ibm.com>

from Build_Engine.Distro import *

class RHEL(Distro):

    def populate_builds_announced(self, user, password, release, release_build_link):
	
        if (re.search("-", release)):
            (Endian, version) = re.split("-", release)
        else:
            Endian = "BE"
            version = release
        
        print('Here 1') 
        print(release_build_link)
        temp_file = tempfile.TemporaryFile()
        rc = subprocess.call(["/usr/bin/wget", "-q", "-O", "-", user, password,
                              release_build_link, "--no-check-certificate"], stdout=temp_file)
        print("/usr/bin/wget", "-q", "-O", "-", user, password, release_build_link, "--no-check-certificate")
        temp_file.seek(0)
        with temp_file:
            for lines in temp_file:
                print('Here 2')
                lines = lines.decode()
                lines = lines.strip()
                if not lines.isspace():
                    is_it_release = re.search("File", lines)
                    if (is_it_release is None):
                        build = re.search(
                            ".*>RHEL-(" + version + ".*)</a>.*", lines)
                        if (build is not None):
                            #print (build)
                            buildname = build.group(1).strip("/")
                            check = re.search(version + '-', buildname)
                            if (check):
                                buildname = buildname.replace(check.group(), '')
                                builds_announced.append(buildname)

        builds_announced.sort()
        logging.info('Builds announced %s', str(builds_announced))
        print('RHEL:Builds announced %s', str(builds_announced))

    def populate_builds_copied(self, release, release_build_copied):
        if release_build_copied is not None:
            with open(release_build_copied, 'r') as file:
                for builds in file:
                    builds = builds.rstrip()
                    builds_copied.append(builds)

            builds_copied.sort()
            logging.info('Builds copied %s', str(builds_copied))
            return SUCCESS

    def copy_rhel_build(self, user, password, release, release_new, build_name, final_dir_structure):
        rc = self.copy_rhel_md5(user, password, release,
                                release_new, build_name, final_dir_structure)
        if (rc != 0):
            self.LOG('May be the complete directory contents of build are not available yet. Will try in another hour',
                     release.lower(), build_name.lower())
            return MD5_NA
        else:
            rc = self.copy_rhel_iso(
                user, password, release, release_new, build_name, final_dir_structure)
            if (rc != 0):
                return FAIL

    def copy_rhel_md5(self, user, password, release, release_new, build_name, final_dir_structure):
        if (re.search("-", release)):
            (Endian, version) = re.split("-", release)
        else:
            Endian = "BE"
            version = release
        is_it_LE = re.search("LE", release)
        build = str(build_name)
        if release.split('-')[1].startswith("7"):
            url='/Server/ppc64le/iso/'
        else:
            url='/BaseOS/ppc64le/iso/'
        if(is_it_LE is not None):
            intermediatelink = parser.get(
                'Location', 'base_link') + 'RHEL-' + version + '-' + build_name + url
        else:
            intermediatelink = parser.get(
                'Location', 'base_link') + 'RHEL-' + version + '-' + build_name + url
        print("copy_rhel_md5: final_dir_structure=%s" % final_dir_structure)
        print("copy_rhel_md5: intermediatelink = %s" % intermediatelink)

        local_md5_file = final_dir_structure + '/MD5SUM'

        # retrieving the link for correct md5sum file from the corresponding
        # page
        md5link = ''
        temp_file = tempfile.TemporaryFile()
        rc = subprocess.call(["/usr/bin/wget", "-q", "-O", "-", user, password,
                              intermediatelink, "--no-check-certificate"], stdout=temp_file)
        temp_file.seek(0)
        with temp_file:
            for lines in temp_file:
                lines = lines.strip()
                if not lines.isspace():
                    is_it_dvd = re.search(b"dvd1", lines)
                    if is_it_dvd is not None:
                        search_str = ".*>(RHEL-.*\.MD5SUM)</a>"
                        search_str = bytes(search_str, 'utf-8')
                        md5link = re.search(search_str, lines)
                        if md5link is not None:
                            md5link = md5link.group(1)
                            break
        md5link = md5link.decode()
        md5_file = intermediatelink + md5link
        print("copy_rhel_md5: md5_file=%s" % md5_file)

        # downloading the md5sum file
        rc = subprocess.call(["/usr/bin/wget", "-q", md5_file, user,
                              password, "--no-check-certificate", "-O", local_md5_file])
        if (rc == 0):
                    self.LOG('Successfully copied MD5SUM ' + os.getcwd(),
                            release_new, build_name.lower())
                    return SUCCESS
        else:
            self.LOG('Failed to copy MD5SUM', release_new, build_name.lower())
            return FAIL

    def copy_rhel_iso(self, user, password, release, release_new, build_name, final_dir_structure):
        md5_file = final_dir_structure + '/MD5SUM'
        print ('i am in iso1')
        with open(md5_file, 'r') as file:
            for lines in file:
                lines = lines.strip()
                if not lines.isspace():
                    is_it_iso = re.search("iso", lines)
                    if (is_it_iso is not None):
                        print("copy_rhel_iso: line=%s" % lines)
                        iso_file = lines.split(" ")[1].strip("*").strip("(").strip(")i.strip(':')")
                        #iso_file = lines.split(" ")[1].strip("*").strip("(").strip(")") 
                        print("copy_rhel_iso: iso_file=%s" % iso_file)
                        if (re.search("-", release)):
                            (Endian, version) = re.split("-", release)
                        else:
                            Endian = "BE"
                            version = release
                        is_it_LE = re.search("LE", release)
                        if release.split('-')[1].startswith("7"):
                            url='/Server/ppc64le/iso/'
                        else:
                            url='/BaseOS/ppc64le/iso/'
                        print("i am in iso")
                        if(is_it_LE is not None):
                            full_iso_file = parser.get(
                                'Location', 'base_link') + 'RHEL-' + version + '-' + build_name + url + iso_file
                                #'Location', 'base_link') + 'RHEL-' + version + '-' + build_name + '/Server/ppc64le/iso/' + iso_file
                        else:
                            full_iso_file = parser.get(
                                'Location', 'base_link') + 'RHEL-' + version + '-' + build_name + url + iso_file
                                #'Location', 'base_link') + 'RHEL-' + version + '-' + build_name + '/Server/ppc64/iso/' + iso_file

                        local_iso_file = final_dir_structure + '/' + iso_file
                        print("copy_rhel_iso: full_iso_file=%s" % full_iso_file)

                        rc = subprocess.call(["/usr/bin/wget", user, password, "-q", full_iso_file,
                                              user, "--no-check-certificate", "-O", local_iso_file])
                        if (rc == 0):
                            self.LOG('Successfully copied iso_file to ' +
                                     os.getcwd(), release_new, build_name.lower())
                            return SUCCESS
                        else:
                            self.LOG('Failed to copy iso ',
                                     release_new, build_name.lower())
                            self.LOG('MANUAL INTERVENTION REQUIRED',
                                     release_new, build_name.lower())
                            return FAIL

    def initiate_rhel_build_copy(self, user, password, release, release_new, config_path):
        # Create the directory structure
        for build in new_builds[:]:
            print (build)
            final_dir_structure = parser.get(
                'Location', 'dir_structure') + release_new + '/' + build.lower()
            self.LOG('Starting copying of ' + build.lower() +
                     ' for ' + release_new, release_new, build.lower())
            rc = self.create_dir_structure(
                release_new, build.lower(), final_dir_structure)
            if (rc != 0):
                self.LOG('Failed to copy build', release_new, build.lower())
                #return FAIL

            # downloading the md5sum and iso file from ftp
            rc = self.copy_rhel_build(
                user, password, release, release_new, build, final_dir_structure)
            if (rc != 0):
                if (rc == 2):
                    self.restore_for_copy_again(
                        release_new, build.lower(), final_dir_structure)
                    return FAIL
            rc = self.check_md5sum(
                release_new, build.lower(), final_dir_structure)
            if (rc != 0):
                self.LOG('MD5 check failed. Will try copy again',
                         release_new, build.lower())
                self.restore_for_copy_again(
                    release_new, build.lower(), final_dir_structure)
                return FAIL
            else:
                self.publish_build(release_new, build.lower(),
                                   parser.get('Location', 'dir_structure'), config_path)
                self.Version(build.lower())
                self.update_builds_copied(release_new, build)
                self.notify_jenkins('rhel', release_new,
                                    build.lower(), final_dir_structure)
            self.notify_build_copy(
                self.__class__.__name__, release_new, build.lower(), final_dir_structure, config_path)

