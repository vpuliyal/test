#!/usr/bin/python

import os
import sys

#return_value=os.system('/home/jenkins/jenkins_home/workspace/build_notifier/ltc-crtl/distro_build_notification/poll_build_notification.py')
return_value=os.system('/home/jenkins/workspace/buildnotifier/Build_Engine/poll_build_notification.py')

if return_value:
    sys.exit(1)
else:
    sys.exit(0)
