

def  jenkins_cron_job():
    global builds_announced,builds_copied,new_builds,ftp3_user,ftp3_password,md5link_announced,release
    buildtrigger = 0
    buildstop = 0

    """Creating RHEL object"""
    rhel_build =   RHEL(BASE_PATH + "/rhel_config.ini")
    release_list = rhel_build.reading_configFile()
    # the username and password required for ftp login is read from the config
    # file and passed on to the functions
    ftp3_user = '--user=' + parser.get('Email', 'user')
    ftp3_password = '--password=' + parser.get('Email', 'passwd')
    release_build_link = parser.get('Location', 'base_link')
    for release in release_list:
        builds_announced = []
        builds_copied = []
        new_builds = []

        if release > '7':
            if re.search("LE", release) is not None:
                temp = release.lower().split('-')
                release_new = temp[1] + temp[0]
            else:
                release_new = release.lower() + 'be'
        else:
            release_new = release.lower()

        rhel_build.populate_builds_announced(
            ftp3_user, ftp3_password, release, release_build_link)
        Release_build_copied = rhel_build.build_copied(release_new)
        rhel_build.populate_builds_copied(release.lower(), Release_build_copied)
        new_builds = rhel_build.compare_for_newbuild()
        if new_builds:
            buildtrigger=1
            buildstop=0
        else:
            buildstop=1

    suse_build = SUSE(BASE_PATH + "/suse_config.ini")
    release_list = suse_build.reading_configFile()
    # the username and password required for ftp login is read from the config
    # file and passed on to the functions
    ftp3_user = '--user=' + parser.get('Email', 'user')
    ftp3_password = '--password=' + parser.get('Email', 'passwd')
    release_build_link = parser.get('Location', 'base_link')
    for release in release_list:
        builds_announced = []
        md5link_announced = []
        builds_copied = []
        new_builds = []
        suse_build.populate_builds_announced(
            ftp3_user, ftp3_password, release, release_build_link)
        Release_build_copied = suse_build.build_copied(release)
        suse_build.populate_builds_copied(release, Release_build_copied)
        new_builds = suse_build.compare_for_newbuild()
        if new_builds:
            buildtrigger=1
            buildstop=0
        else:
            buildstop=1

    if buildtrigger == 1:
            sys.exit(0)

    if buildstop==1:
            sys.exit(1)

