
from Build_Engine.ubuntu_build_engine import *
from Build_Engine.Distro import *

def ubuntu_obj():
    ubuntu_build = UBUNTU()
    now = datetime.datetime.now()
    present_day=calendar.day_name[now.weekday()]
    time_window = now.replace(hour=23, minute=19, second=59, microsecond=59)
    time_window1 = now.replace(hour=22, minute=1, second=00, microsecond=00)
    complete_file = parser.read(BASE_PATH + "/ubuntu_config.ini")

    #if (present_day=="Thursday" and now <= time_window and now >= time_window1):
    non_lts_section = (parser.items("non-lts_path"))
    for (build_name,build_path) in non_lts_section:
        rc = ubuntu_build.copy_ubuntu_md5(build_name,build_path)
        if not rc:
            ubuntu_build.non_lts_builds(build_name,build_path) #Function call to download files
            pass
        else:
            logging.info("Already downloaded, not downloading")

    lts_section = (parser.items("lts_Path"))
    for (build_name,build_path) in lts_section:
        build_name_number = re.findall("\d{2}.\d{2}.\d", build_name) #Regular expression to obtain the number from build name
        build_name = re.findall("\w+-\w+", build_name)  #Regular expression to obtain the release_name from build name
        release_number = ''.join(build_name_number)
        build_name = ''.join(build_name)
        ubuntu_build.lts_builds(build_name,build_path) #Function call to download files

