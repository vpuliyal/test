# buildnotifier
Script for buildnotifier


Copy tar file to below location : 
[root@ci-http-results buildnotifier]# pwd
/home/jenkins/workspace/
[root@ci-http-results buildnotifier]#
 
