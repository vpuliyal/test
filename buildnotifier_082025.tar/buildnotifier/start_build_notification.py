#!/usr/bin/python
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See LICENSE for more details.
#
# Copyright: 2022 IBM
# Author :Vaishnavi Bhat <vaishnavi@linux.vnet.ibm.com?
#        :Praveen K Pandey <praveen@linux.vnet.ibm.com>
#        :Samir A Mulani <samir@linux.vnet.ibm.com> 

from Build_Engine.build_notification import *

"""
Start of the build process
"""
if __name__ == "__main__":
    BASE_PATH = os.path.dirname(os.path.abspath(__file__))
    build_check_copy(BASE_PATH)
