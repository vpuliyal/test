#!/bin/bash
set -x
# Make sure root can NOT run this script
#if [ "$(id -u)" = "0" ]; then
   #echo "This script can not be run as root" 1>&2
   #exit 1
#fi

export PATH=/sbin:$PATH
while getopts u:l:i:g:d: OPTION
do
        case ${OPTION} in
               u) USERS=${OPTARG} ;;
               l) DURATION=${OPTARG} ;;
               i) SESSION=${OPTARG} ;;
               g) GROUP_ID=${OPTARG} ;;
               d) DESC=${OPTARG}  ;;
               ?) Usage; exit 2 ;;
        esac
done

USERS=${USERS:-10}
DURATION=${DURATION:-120}
SESSION=${SESSION:-1}
GROUP_ID=${GROUP_ID:-0}
DESC=${DESC:-"Test Run"}
RAMPUP=${RAMPUP:-0}

#echo $RAMPUP
echo $USERS
echo $DURATION

#RUNS_DIR=$(pwd)/RUNS
RUNS_DIR=/root/RUNS
if [ ! -d $RUNS_DIR ]
then

mkdir -p $RUNS_DIR
chmod -R 777 $RUNS_DIR
fi

LAST_RUN=$RUNS_DIR/.latest_run
#echo $LAST_RUN
if [ -e $LAST_RUN ] ; then
        id=$(cat $LAST_RUN)
else
        touch $LAST_RUN
        chmod a+rw $LAST_RUN
        cd $RUNS_DIR
        id=$(ls -1d [0-9]* 2>/dev/null | sort -nr | head -1)
        cd ../
fi
#echo $id
RUNID=$(($id+1))
CUR_RUN_DIR=$RUNS_DIR/$RUNID
#echo $CUR_RUN_DIR
#Updating last runid immediately, so that after a failed run the last id will not be used
echo $RUNID >$LAST_RUN

mkdir -p $CUR_RUN_DIR
#sudo chmod -R 777 $CUR_RUNS_DIR

date |tee -a  $CUR_RUN_DIR/console_dat.log

### Restore DBs
/root/bin/Restore_Multiple_Tradedbs.sh $SESSION  |tee -a $CUR_RUN_DIR/console_dat.log
#/home/db2inst1/bin/Restore_Multiple_Tradedbs.sh $SESSION  |tee -a $CUR_RUN_DIR/console_dat.log

sleep 10
### Start Liberty Servers
/root/bin/Start_Multiple_Liberty_Servers.sh $SESSION |tee -a $CUR_RUN_DIR/console_dat.log
#/home/db2inst1/bin/Start_Multiple_Liberty_Servers.sh $SESSION |tee -a $CUR_RUN_DIR/console_dat.log

sleep 10
## Check Binding
for pid in `seq 1 $SESSION`; do PID=`ps -ef|grep server$pid|grep -v grep|awk '{print $2}'`; taskset -pc $PID |tee -a $CUR_RUN_DIR/console_dat.log; done

sleep 10
### Reset DBs
/root/bin/Reset_Multiple_TraderDBs.sh $SESSION |tee -a $CUR_RUN_DIR/console_dat.log
#/home/db2inst1/bin/Reset_Multiple_TraderDBs.sh $SESSION |tee -a $CUR_RUN_DIR/console_dat.log

sleep 10
echo "Collect pidstat data even from warmup phase." | tee -a $CUR_RUN_DIR/console_dat.log
pidstat -t -C java 30 70 >> $CUR_RUN_DIR/pidstat_java.out &
pidstat -t -C jmeter 30 70 >> $CUR_RUN_DIR/pidstat_jmeter.out &
pidstat -t -C db2sysc 30 70 >> $CUR_RUN_DIR/pidstat_db2sysc.out &


/root/numa.sh 35 >> $CUR_RUN_DIR/numa_java.out &

### WarmUp DBs
/root/bin/Warmup_Multiple_Liberty_Servers.sh $SESSION $USERS |tee -a $CUR_RUN_DIR/console_dat.log
#/home/db2inst1/bin/Warmup_Multiple_Liberty_Servers.sh $SESSION $USERS |tee -a $CUR_RUN_DIR/console_dat.log

cd /root
rm -rf perf_dt7.sh
#cd /home/db2inst1
wget http://ci-http-results.pperf.tadn.ibm.com/perfTest/scripts/perf_ci.sh
chmod 777 perf_dt7.sh
echo " Welcome to DayTrader7 test "
echo "Starting the DayTrader7 test" |tee -a $CUR_RUN_DIR/console_dat.log
date  |tee -a $CUR_RUN_DIR/console_dat.log

count=1
HOST=127.0.0.1
while [ $count -le  $SESSION ]
do
echo "start jmeter on " $count
let PORT=$count*100+10000
echo "cd /root/apache-jmeter-3.0/bin; ./jmeter -n -t daytrader7.jmx -JHOST=$HOST -JPORT=$PORT -JTHREADS=$USERS -j /root/jmeter.log_$count -JDURATION=$DURATION & " |tee -a run_cmd.tmp
#echo "cd /home/db2inst1/apache-jmeter-3.0/bin; ./jmeter -n -t daytrader7.jmx -JHOST=$HOST -JPORT=$PORT -JTHREADS=$USERS -j /home/db2inst1/jmeter.log_$count -JDURATION=$DURATION & " |tee -a run_cmd.tmp
sleep 1
let count=$count+1
done

echo "sleep $DURATION" |tee -a run_cmd.tmp

chmod +x run_cmd.tmp

/root/perf_dt7.sh $CUR_RUN_DIR &
/root/lpcpu/lpcpu.sh duration=$DURATION interval=10 cmd="./run_cmd.tmp" output_dir="$CUR_RUN_DIR" |tee -a $CUR_RUN_DIR/console_dat.log
#/home/db2inst1/lpcpu/lpcpu.sh duration=$DURATION interval=10 cmd="./run_cmd.tmp" output_dir="$CUR_RUN_DIR" |tee -a $CUR_RUN_DIR/console_dat.log
#/home/db2inst1/lpcpu/lpcpu.sh duration=$DURATION interval=10 cmd="" output_dir="$CUR_RUN_DIR" ./run_cmd.tmp |tee -a $CUR_RUN_DIR/console_dat.log


cd /root
#cd /home/db2inst1

date
sleep 5
echo $CUR_RUNS_DIR
mv  jmeter.log_* run_cmd.tmp $CUR_RUN_DIR

echo "generating DayTrader7 report "
#./gen_report.sh $RUNID $GROUP_ID "$DESC" $SESSION
# Generate Report
/root/bin/gen_report.sh $RUNID $GROUP_ID "$DESC" $SESSION |tee -a $CUR_RUN_DIR/console_dat.log
#/home/db2inst1/bin/gen_report.sh $RUNID $GROUP_ID "$DESC" $SESSION |tee -a $CUR_RUN_DIR/console_dat.log
#echo $RUNID >$LAST_RUN
cd $CUR_RUN_DIR
lpcpu=$(ls | grep lpcpu_data | wc -l)
if [ $lpcpu -eq 1  ]; then
    tar=$(ls | grep lpcpu_data)
    tar -cvf $tar.tar.bz2  lpcpu_data*
else
   echo " lpcpu_data tar file exists"
fi
if [ $(find $CUR_RUN_DIR -type f -name "*tar.bz2.tar.bz2" | wc -l ) != "0" ] ; then
echo "tar.bz2.tar.bz2* was there  "
 cd $CUR_RUN_DIR
 rm -rf *tar.bz2.tar.bz2
else

echo " nothing to be delete "
fi

#cp workload.info_temp $CUR_RUN_DIR

cd $CUR_RUN_DIR
DATETIME=`date +%F_%H%M`
#cat workload.info | awk '{printf("%s",$1);}END{printf("\n");}' >>  workload.info_temp
#mv workload.info_temp workload.info
#tar -cvf DayTrader7_rundata.tar jmeter.log_* console_dat.log report.out lpcpu*.tar.bz2
#tar -cvf DayTrader7_ipds_$RUNID_$DATETIME.tar workload.info lpcpu*.tar.bz2 jmeter.log_* console_dat.log report.out perf* operf* pm* numa_java* pidstat* 
#mkdir -p data
#mv workload.info lpcpu*.tar.bz2 jmeter.log_* console_dat.log report.out perf* operf* pm* numa_java* pidstat* data
tar cvj -f DT7_"$kernelrelease"_"$DATETIME".tar.bz2 data
### Stop Liberty Servers
echo "Run finished!! Stop Liberty server and DB2"
/root/bin/Stop_Multiple_Liberty_Servers.sh $SESSION |tee -a $CUR_RUN_DIR/console_dat.log
#/home/db2inst1/bin/Stop_Multiple_Liberty_Servers.sh $SESSION |tee -a $CUR_RUN_DIR/console_dat.log

### Stop DB
#db2stop force
su - db2inst1 "-c db2stop force"


cat /root/RUNS/$RUNID/report.out
#cat /home/db2inst1/RUNS/$RUNID/report.out
cd -
echo "Daytrader7 test is complete!!" |tee -a $CUR_RUN_DIR/console_dat.log
#sshpass -p 'zxcvbnm123' scp $CUR_RUN_DIR/DayTrader7_ipds_$RUNID.tar vpuliyal@ipds.aus.stglabs.ibm.com:/data/incoming
#sshpass -p 'zxcvbnm123' scp -o "StrictHostKeyChecking no" $CUR_RUN_DIR/DayTrader7_ipds_$RUNID_$DATETIME.tar vpuliyal@ipds.aus.stglabs.ibm.com:/data/incoming

date |tee -a $CUR_RUN_DIR/console_dat.log

